import React, { Component } from "react";
import { Link } from "react-router-dom";
import company_logo from '../../media/image/centpays_full_logo.png'
// import { Link } from "react-router-dom";

// sidebar icon
import {CircleRing, Dashboard, MasterSettings, ManageMerchant, APIdoc, PaymentGateway, ManageUser, TransactionMonitoring, 
	TransactionReport, ManageSettlement, DownSign, RightSign } from "../../media/icon/SVGicons"

class Sidebar extends Component {
	constructor(props) {
		super(props);
		this.state = {
			sidebaropen: true,
			menuOpen: {
				masterSetting: false,
				manageMerchant: false,
				manageUser: false,
				transactionReport: false,
				manageSettlement: false,
				dashboard : true,
			},
		};
	}

	handleMenuClick = (menuItem) => {
		this.setState(prevState => ({
			menuOpen: {
				...prevState.menuOpen,
				[menuItem]: !prevState.menuOpen[menuItem]
			}
		}));
	}

	render() {
		const { sidebaropen, menuOpen } = this.state;
		return (
			<>
				<div className={`sidebar ${sidebaropen ? "expanded-sidebar" : "collapsed-sidebar"}  `}>
					<div className="sidebar-container">
						<div className="sidebar-header">
							<img src={company_logo} alt="Centpays Company Logo" />
							<input type="radio" />
						</div>
						<div className="sidebar-middle">
							<ul>
								<li>
									<div className={`menu-item ${menuOpen.dashboard ? 'sidebaractive' : ''}`}>
										{/* <img src={dashboard} className="icon" alt="" /> */}
										<Dashboard className='icon menu-item-icon-color'/>
										<Link to="/dashboard"><div className="menu-item-collapsive" onClick={() => this.handleMenuClick('dashboard')}>  <p>Dashboard<i style={{ color: 'red' }}>*</i></p> </div></Link>
									</div>
								</li>
								<li className="menuitem-disable">
									<div className={`menu-item ${menuOpen.masterSetting ? 'sidebaractive' : ''}`}>
										<MasterSettings className='icon menu-item-icon-color'/>
										<div className="menu-item-collapsive" onClick={() => this.handleMenuClick('masterSetting')}><p>Master Setting</p> {menuOpen.masterSetting === true ? <DownSign className='icon'/> : <RightSign className='icon'/>}</div>
									</div>
								</li>
								{menuOpen.masterSetting && (
									<ul className="sub-menu">
										<Link to="/businesstype"><li><CircleRing className='sub-menu-icon'/><div><p>Business Types</p> </div></li></Link>
										<Link to="/categories"><li><CircleRing  className='sub-menu-icon'/><div><p>Categories</p> </div></li></Link>
										<Link to="/businesssubcategories"><li><CircleRing  className='sub-menu-icon'/><div><p>Business Sub Categories</p> </div></li></Link>
										<Link to="/managecurrencies"><li><CircleRing  className='sub-menu-icon'/><div><p>Manage Currencies</p> </div></li></Link>
										<Link to="/documenttype"><li><CircleRing  className='sub-menu-icon'/><div><p>Documet Types</p> </div></li></Link>
										<Link to="/documentcategory"><li><CircleRing  className='sub-menu-icon'/><div><p>Document Categories</p> </div></li></Link>
										<Link to="/bank"><li><CircleRing  className='sub-menu-icon'/><div><p>Banks</p> </div></li></Link>
									</ul>)
								}
								<li ><div className={`menu-item ${menuOpen.manageAPIDoc ? 'sidebaractive' : ''}`}><ManageMerchant className='icon menu-item-icon-color'/><Link to='/allmerchant'><div className="menu-item-collapsive" onClick={() => this.handleMenuClick('manageMerchant')} ><p>Manage Merchant<i style={{ color: 'red' }}>*</i></p></div></Link></div></li>

								<li className="menuitem-disable"><div className={`menu-item ${menuOpen.manageAPIDoc ? 'sidebaractive' : ''}`}><APIdoc className='icon menu-item-icon-color'/><div className="menu-item-collapsive" onClick={() => this.handleMenuClick('manageAPIDoc')} ><p>Manage API Doc<i style={{ color: 'red' }}>*</i></p></div></div></li>
								<li className="menuitem-disable"><div className={`menu-item ${menuOpen.paymentGateway ? 'sidebaractive' : ''}`}><PaymentGateway className='icon menu-item-icon-color'/><div className="menu-item-collapsive" onClick={() => this.handleMenuClick('paymentGateway')}><p>Payment Gateway<i style={{ color: 'red' }}>*</i></p></div></div></li>
								<li className="menuitem-disable">
									<div className={`menu-item ${menuOpen.manageUser ? 'sidebaractive' : ''}`}>
										{/* <img src={manageUser} className="icon" alt="" /> */}
										<ManageUser className='icon menu-item-icon-color'/>
										<div className="menu-item-collapsive" onClick={() => this.handleMenuClick('manageUser')}><p>Manage User</p> {menuOpen.manageUser === true ? <DownSign className='icon'/> : <RightSign className='icon'/>}</div>
									</div>
								</li>
								{menuOpen.manageUser && (
									<ul className="sub-menu">
										<Link to="/adduser"><li><div><p>Add User</p> </div></li></Link>
										<Link to="/alluser"><li><div><p>All USer</p> </div></li></Link>
									</ul>
								)}

								<li ><div className="menu-item"><TransactionMonitoring className='icon menu-item-icon-color'/><Link to='/transactionmonitoring'> <div className="menu-item-collapsive" ><p>Tranaction Monitoring<i style={{ color: 'red' }}>*</i></p></div></Link></div></li>
								<li className="menuitem-disable">
									<div className={`menu-item ${menuOpen.transactionReport ? 'sidebaractive' : ''}`}>
										{/* <img src={txnReport} className="icon" alt="" /> */}
										<TransactionReport className='icon menu-item-icon-color'/>
										<div className="menu-item-collapsive" onClick={() => this.handleMenuClick('transactionReport')}><p>Transaction Report</p>{menuOpen.transactionReport === true ? <DownSign className='icon'/> : <RightSign className='icon'/>}</div>
									</div>
								</li>
								{menuOpen.transactionReport && (
									<ul className="sub-menu">
										<Link to="/transactionreport"><li><div><p>Transaction Report</p> </div></li></Link>
										<Link to="/tempreport"><li><div><p>Temp Report</p> </div></li></Link>
										<Link to="/tempureport"><li><div><p>Temp Unique Order Report</p> </div></li></Link>
										<Link to="/tempcreport"><li><div><p>Temp Common Order Report</p> </div></li></Link>
										<Link to="/payoutreport"><li><div><p>Payout Report</p> </div></li></Link>
										<Link to="/compare"><li><div><p>Compare</p> </div></li></Link>
									</ul>
								)}

								<li ><div className={`menu-item ${menuOpen.manageSettlement ? 'sidebaractive' : ''}`}><ManageSettlement className='icon menu-item-icon-color'/><Link to='/settlements'><div className="menu-item-collapsive" onClick={() => this.handleMenuClick('manageSettlement')}><p>Manage Settlement<i style={{ color: 'red' }}>*</i></p></div></Link></div></li>

								<li>
									<div className={`menu-item ${menuOpen.aqtest ? 'sidebaractive' : ''}`}>
										<Dashboard className='icon menu-item-icon-color'/>
										<Link to="/acquirertestingenv"><div className="menu-item-collapsive" onClick={() => this.handleMenuClick('aqtest')}>  <p>AQ Test<i style={{ color: 'red' }}>*</i></p> </div></Link>
									</div>
								</li>
							</ul>
						</div>
						<div className="sidebar-footer"></div>
					</div>
				</div>
			</>
		);
	}
}

export default Sidebar;